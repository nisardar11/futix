# FUTIX — Free AI Study Interface

A browser-based AI assistant with 5 tools: **AI Chat, Translate, Summarize, Solve, Study**.
English + Arabic interface. 100% free, no server, no build step — just one `index.html`.

## How it works (all free)
| Tool | Service used | Key needed? |
|---|---|---|
| Chat / Summarize / Solve / Study | Pollinations free AI API | No |
| Translate | MyMemory free API (AI fallback) | No |
| Backup AI (optional) | Google Gemini or Groq free tier | Free key, entered in ⚙ Settings |

If the free AI is busy, the ⚙ button lets any user add their own free key; it is saved **only in that user's browser** (never in this repo).
Never put an API key inside `index.html` — GitHub is public.

## Publish on GitHub Pages (free)
1. Create a new **public** repository on github.com.
2. Click **Add file → Upload files**, drag in everything from this folder, **Commit**.
3. Go to **Settings → Pages → Build and deployment**: Source = *Deploy from a branch*, Branch = `main`, Folder = `/ (root)`, **Save**.
4. After ~1 minute the site is live at `https://YOUR-USERNAME.github.io/REPO-NAME/`.

Every time you edit and commit `index.html`, the site updates automatically.
